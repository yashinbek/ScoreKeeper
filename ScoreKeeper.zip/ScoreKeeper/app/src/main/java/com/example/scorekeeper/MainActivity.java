package com.example.scorekeeper;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int scoreTeamFifa = 0;
    int scoreTeamBarselona = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void addFourForTeamFifa(View v){
        scoreTeamFifa = scoreTeamFifa+4;
        displayForTeamFifa(scoreTeamFifa);
    }

    public void addFourForTeamBarselona(View v){
        scoreTeamBarselona = scoreTeamBarselona+4;
        displayForTeamBarselona(scoreTeamBarselona);
    }

    public void addThreeForTeamFifa(View v){
        scoreTeamFifa = scoreTeamFifa+3;
        displayForTeamFifa(scoreTeamFifa);
    }

    public void addThreeForTeamBarselona(View v){
        scoreTeamBarselona = scoreTeamBarselona+3;
        displayForTeamBarselona(scoreTeamBarselona);
    }

    public void addTwoForTeamFifa(View v){
        scoreTeamFifa = scoreTeamFifa+2;
        displayForTeamFifa(scoreTeamFifa);
    }

    public void addTwoForTeamBarselona(View v){
        scoreTeamBarselona = scoreTeamBarselona+2;
        displayForTeamBarselona(scoreTeamBarselona);
    }

    public void addOneForTeamFifa(View v){
        scoreTeamFifa = scoreTeamFifa+1;
        displayForTeamFifa(scoreTeamFifa);
    }

    public void addOneForTeamBarselona(View v){
        scoreTeamBarselona = scoreTeamBarselona+1;
        displayForTeamBarselona(scoreTeamBarselona);
    }

    public void resetScore (View v){
        scoreTeamFifa = 0;
        scoreTeamBarselona = 0;
        displayForTeamFifa(scoreTeamFifa);
        displayForTeamBarselona(scoreTeamBarselona);
    }

    public void displayForTeamFifa(int score){
        TextView scoreView = (TextView)findViewById(R.id.team_Fifa_score);
        scoreView.setText(String.valueOf(score));
    }

    public void displayForTeamBarselona(int score){
        TextView scoreView = (TextView)findViewById(R.id.team_Barselona_score);
        scoreView.setText(String.valueOf(score));
    }
}